package com.ssgpack.ssgfc.player;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.springframework.stereotype.Service;

@Service
public class PlayerCrawlService {

    public List<Player> crawlSSGPlayers() {
        List<Player> players = new ArrayList<>();

        // 크롬 드라이버 경로 설정
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver.exe");

        // ✅ 브라우저 안 띄우고 headless 모드로 실행
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless"); // 화면 없이
        options.addArguments("--disable-gpu");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");

        WebDriver driver = new ChromeDriver(options);

        try {
            driver.get("https://www.koreabaseball.com/Record/Player/HitterBasic/Basic1.aspx?teamCode=SSG");

            List<WebElement> rows = driver.findElements(By.cssSelector("table.tData tbody tr"));
            for (WebElement row : rows) {
                List<WebElement> cols = row.findElements(By.tagName("td"));
                if (cols.size() > 3) {
                    String name = cols.get(1).getText();
                    String avgStr = cols.get(3).getText();

                    Player player = new Player();
                    player.setName(name);
                    player.setPosition("SSG");
                    try {
                        player.setAvg(Double.parseDouble(avgStr));
                    } catch (NumberFormatException e) {
                        player.setAvg(0.0);
                    }

                    // 콘솔 출력 확인
                    System.out.println("이름: " + player.getName() + ", 타율: " + player.getAvg());

                    players.add(player);
                }
            }

        } catch (Exception e) {
            System.out.println("크롤링 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        } finally {
            driver.quit();
        }

        return players;
    }
}