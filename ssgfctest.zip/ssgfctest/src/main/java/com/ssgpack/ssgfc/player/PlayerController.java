package com.ssgpack.ssgfc.player;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class PlayerController {

    private final PlayerCrawlService crawlService;
    private final PlayerRepository playerRepository;

    // ✅ [1] 크롤링 + DB 저장 (기존 유지)
    @PostMapping("/api/player/crawl/ssg")
    public ResponseEntity<String> crawlSSG() {
        try {
            List<Player> players = crawlService.crawlSSGPlayers(); // 콘솔도 찍히고 DB에도 저장됨
            playerRepository.saveAll(players);
            return ResponseEntity.ok(players.size() + "명 저장 완료");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("크롤링 실패: " + e.getMessage());
        }
    }

    // ✅ [2] 저장 없이 콘솔에만 출력 (★ 이거 추가!)
    @GetMapping("/api/player/print")
    public String printToConsoleOnly() {
        crawlService.crawlSSGPlayers(); // 콘솔에서만 출력됨
        return "콘솔에 출력 완료!";
    }

    // ✅ [3] 저장된 선수 전체 보기
    @GetMapping("/api/players")
    public List<Player> getPlayers() {
        return playerRepository.findAll();
    }
}